package operations;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import virtualKeyRep.VR;

public class Operations {
	
	static Scanner sn = new Scanner(System.in);
	static String directory = "src/storage";

	public static void FileOperations() {
		System.out.println("");
		System.out.println("Press 1 to Add a file");
		System.out.println("Press 2 to Delete a file");
		System.out.println("Press 3 to Search a file");
		System.out.println("Press 4 to go Back to the Main Menu");
		
		String choice = sn.nextLine();
		handle(choice);
	}
	
	public static void handle(String num) {
		switch(num) {
			case "1":
				System.out.println("You selected Add Operation. Please give file name (ex abc.txt)");
				add();
				break;
			case "2":
				System.out.println("You selected Delete Operation");
				delete();
				break;
			case "3":
				System.out.println("You selected Search Operation");
				search();
				break;
			case "4":
				System.out.println("Going Back to Main Menu");
				VR.mainmenu();
				break;				
			default:
				System.out.println("Invalid input");
		}
		FileOperations();
	}
	

	private static void add() throws InvalidPathException{
		  String input = sn.nextLine();
		  
          File file = new File("d://workspace//phase1//src//storage//" + input);
         		
  
          //Create the file
          try {
			if (file.createNewFile()){
			    System.out.println("File is created!");
			    System.out.println("Enter key");
			    FileWriter writer;
				writer = new FileWriter(file);
				String key = sn.nextLine();
				writer.write(key);
				writer.close();
			  }else{
			    System.out.println("File already exists.");
			  }
		} catch (InvalidPathException | IOException e) {
			    e.printStackTrace();
		}     
    }
	// to delete a file
	
	public static void delete() throws InvalidPathException {
		System.out.println("Enter the file path (ex: c.txt)");
		String input = sn.nextLine();
		
		String Path = directory + "/" + input;
		Path path;
		
		try {
			path = Paths.get(Path);	
		} catch (Exception e) {
			System.out.println("Invalid input");
			return;
		}
		
		if (!Files.exists(path)) {
			System.out.println("No such file existed,thus cannot be deleted");
			return;
		} else {
			System.out.println("File is present");
		}
		
		File Delete = new File(Path);
		try {
			Delete.delete();
			System.out.println("File is deleted");
		} 
		catch (Exception e) {
	
			System.out.println("Not able to delete file");
			System.out.println(e);
		}
	}
	
	//to search a file
	
	public static void search() throws InvalidPathException{
		System.out.println("Enter the file to search (ex: a.txt)");	
		String input = sn.nextLine();
		
		String Path = directory + "/" + input;
		Path path;
		
		try {
			path = Paths.get(Path);	
		} catch (Exception e) {
			System.out.println("Invalid input");
			return;
		}
		
		if(!Files.exists(path)) {
			System.out.println("No such file exist");
			return;
		} else {
			System.out.println("File is present");
		}

	}
}

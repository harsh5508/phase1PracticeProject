package virtualKeyRep;

import java.util.*;
import java.io.*;
import operations.*;

public class VR {
	static Scanner sn = new Scanner(System.in);
	static String directory= "src/storage";

	public static void ascendingOrder() {
		
		File[] files = new File(directory).listFiles();
		Set<String> a = new TreeSet<>();
		for(File file : files) {
			if (!file.isFile()) {
				continue;
			}
			a.add(file.getName());
		}
		a.forEach(i->System.out.println(i));

	}
	
	public static void mainmenu() {
		System.out.println("");
		System.out.println("Main Menu");
		System.out.println("Press 1 to show file in Ascending Order");
		System.out.println("Press 2 to view file operations");
		System.out.println("Press 3 to Exit from the application");

		int choice = sn.nextInt();
		handle(choice);
	}
	public static void handle(int num) {
		switch(num) {
			case 1:
				ascendingOrder();
				break;
			case 2:
				Operations.FileOperations();
				break;
			case 3:
				System.out.println("Exit");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid input");
		}
		mainmenu();
	}
	public static void main(String[] args) {
		
		mainmenu();
	
	}
}